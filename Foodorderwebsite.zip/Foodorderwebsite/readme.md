<p align="center"><img src="https://github.com/PrantaRoy/-Restaurant-Management-Laravel/blob/master/public/uploads/Screenshot_1.png"></p>


 <h1>About Restaurant Management Laravel <h1>


 <p align="center">A simple  Restaurant Management System application built with laravel . Here User can view Restaurant menus , Dish, any kind of offers . User also send invitation for Booking  Restaurant . when admin accept user invitation request user got mail and others description .        <p align="center"><img src="https://github.com/PrantaRoy/-Restaurant-Management-Laravel/blob/master/public/uploads/Screenshot_2.png"> <img src="https://github.com/PrantaRoy/-Restaurant-Management-Laravel/blob/master/public/uploads/Screenshot_3.png"> <img src="https://github.com/PrantaRoy/-Restaurant-Management-Laravel/blob/master/public/uploads/Screenshot_4.png"> <img src="https://github.com/PrantaRoy/-Restaurant-Management-Laravel/blob/master/public/uploads/Screenshot_5.png">
      


</p> 
        


        
        

